<?php
include"./init/includes/header1.php";
?>


<main id="main">

<!-- ======= Breadcrumbs ======= -->
<section class="breadcrumbs">
  <div class="container">

    <ol>
      <li><a href="index.html">Home</a></li>
      <li>Project Details</li>
    </ol>
    <h2>Property Details</h2>

  </div>
</section><!-- End Breadcrumbs -->

<!-- ======= Portfolio Details Section ======= -->
<section id="portfolio-details" class="portfolio-details">
  <div class="container">

    <div class="row gy-4">

      <div class="col-lg-8">
       
      </div>
      <div class="col-lg-4">
        <div class="portfolio-info">
           <p> <strong>9West Building</strong></p>
      <h6>  9 West is an iconic 9-storey building centrally located at the heart of Westlands along Ring Road Parklands with accessibility from all business areas of Nairobi. The modern, impressive finishes, fittings and high architectural details create an aesthetic and conducive working environment while the high specification glazing on curtain walls reduces solar gain, providing ample lighting for the entire floor. Services in the building include the high-end restaurant, Bambino, and serviced offices, Kofisi 9.</h6>
</div>
</div>

<div class="row">
                            <div class="col-md-12">
                                <div class="info-box">
          <h3>Amenities and Facilities</h3>
          <ol>
            <li><strong>Large triple volume entrance atrium</strong></li>
            <li><strong>10,000 sq.ft of lettable office space per floor which can be subdivided to allow for 3 separate tenants</strong></li>
            <li><strong>High quality finishes and fittings</strong></li>
            <li><strong>Standby generator providing 100 % maintained power</strong></li>
            <li><strong>Borehole and ample underground water storage</strong></li>
            <li><strong>Provision for air conditioning </strong></li>
            <li><strong>Fire alarm detection system  </strong></li>
            <li><strong>Secure basement parking for 200 cars </strong></li>
            <li><strong>High specification glazing minimizing heat gain and noise pollution</strong></li>
            <li><strong>Central core with high speed lifts </strong></li>
        
          </ol>
        </div>
        
      </div>

    </div>

  </div>
</section><!-- End Portfolio Details Section -->

</main><!-- End #main -->

<?php
include"./init/includes/footer.php";
?>